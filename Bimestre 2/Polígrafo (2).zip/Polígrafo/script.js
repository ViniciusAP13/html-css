var sims = 0
var resps = 0

function clicarsim() {
    resps ++
    sims ++

    if (resps == 0) {
        document.getElementById("p1").style.display = "block"
    } else {
        document.getElementById("p1").style.display = "none"
    }
    
    if (resps == 1) {
        document.getElementById("p2").style.display = "block"
    } else {
        document.getElementById("p2").style.display = "none"
    }

    if (resps == 2) {
        document.getElementById("p3").style.display = "block"
    } else {
        document.getElementById("p3").style.display = "none"
    }

    if (resps == 3) {
        document.getElementById("p4").style.display = "block"
    } else {
        document.getElementById("p4").style.display = "none"
    }

    if (resps == 4) {
        document.getElementById("p5").style.display = "block"
    } else {
        document.getElementById("p5").style.display = "none"
    }
}

function clicarnao() {
    resps ++

    if (resps == 0) {
        document.getElementById("p1").style.display = "block"
    } else {
        document.getElementById("p1").style.display = "none"
    }

    if (resps == 1) {
        document.getElementById("p2").style.display = "block"
    } else {
        document.getElementById("p2").style.display = "none"
    }

    if (resps == 2) {
        document.getElementById("p3").style.display = "block"
    } else {
        document.getElementById("p3").style.display = "none"
    }

    if (resps == 3) {
        document.getElementById("p4").style.display = "block"
    } else {
        document.getElementById("p4").style.display = "none"
    }

    if (resps == 4) {
        document.getElementById("p5").style.display = "block"
    } else {
        document.getElementById("p5").style.display = "none"
    }
}

